$(document).ready(function init(){
	$("a").addClass("discrete");
});

  