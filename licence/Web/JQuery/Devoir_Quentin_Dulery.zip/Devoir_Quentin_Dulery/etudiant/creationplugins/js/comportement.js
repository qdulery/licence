$(document).ready(init());

function init() {
  $("ul.monPlugin").monPlugin({
    "widthAside": 600,
    "heightAside": 200,
    "backgroundColor": "red"
  });
}
